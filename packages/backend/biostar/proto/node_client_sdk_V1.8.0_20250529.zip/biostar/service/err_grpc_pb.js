// GENERATED CODE -- DO NOT EDIT!

'use strict';
var grpc = require('grpc');
var err_pb = require('./err_pb.js');


var ErrorService = exports.ErrorService = {
};

exports.ErrorClient = grpc.makeGenericClientConstructor(ErrorService);
