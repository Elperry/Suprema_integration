const err = require('./err');

module.exports.getMultiError = err.getMultiError;
